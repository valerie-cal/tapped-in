/* generated using openapi-typescript-codegen -- do not edit */
/* istanbul ignore file */
/* tslint:disable */
 
import type { CancelablePromise } from '../core/CancelablePromise';
import type { BaseHttpRequest } from '../core/BaseHttpRequest';
export class DefaultService {
    constructor(public readonly httpRequest: BaseHttpRequest) {}
    /**
     * Load the Google Maps JavaScript API
     * Loads the Maps JavaScript API library for client-side use in a web browser. The 'key' parameter is required for authentication and billing.
     * @param key Your Google Maps Platform API key. **You must restrict this key by HTTP referrer (website URLs) for security.**
     * @param xCreaoApiName API name identifier
     * @param xCreaoApiPath API path identifier
     * @param xCreaoApiId API ID identifier
     * @param callback A global function name to be executed once the API is loaded.
     * @param libraries A comma-separated list of additional libraries to load (e.g., places, geometry, drawing).
     * @returns string Successful script load (the API library is returned and executes in the browser).
     * @throws ApiError
     */
    public loadMapsJavaScriptApi(
        key: string,
        xCreaoApiName: string = 'mapsjavascripapi',
        xCreaoApiPath: string = '/maps/api/js',
        xCreaoApiId: string = '68fd91184ee1dc116d72651f',
        callback?: string,
        libraries?: string,
    ): CancelablePromise<string> {
        return this.httpRequest.request({
            method: 'GET',
            url: '/maps/api/js',
            headers: {
                'X-CREAO-API-NAME': xCreaoApiName,
                'X-CREAO-API-PATH': xCreaoApiPath,
                'X-CREAO-API-ID': xCreaoApiId,
            },
            query: {
                'key': key,
                'callback': callback,
                'libraries': libraries,
            },
            errors: {
                400: `Bad Request (e.g., missing API key or invalid parameters).`,
            },
        });
    }
}
