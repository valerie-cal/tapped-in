/* generated using openapi-typescript-codegen -- do not edit */
/* istanbul ignore file */
/* tslint:disable */
 
/**
 * API ID identifier
 */
export type CreaoApiIdHeader = string;
