import { type MCPToolResponse, useMCPClient } from "@/hooks/use-mcp-client";
import { useMutation, useQueryClient } from "@tanstack/react-query";

// MCP Configuration
const MCP_ID = "686de5276fd1cae1afbb55be";
const SERVER_URL =
	"https://mcp.composio.dev/composio/server/64ddd793-75d0-4c3d-8abf-56c7554f19be/mcp?user_id=68fd8ddc75e06ca1e8950833";
const TOOL_NAME = "GMAIL_SEND_EMAIL";

/**
 * Input parameters for sending email via Gmail
 */
export interface GmailSendEmailInput {
	/** Primary recipient's email address */
	recipient_email: string;
	/** Email content (plain text or HTML); if HTML, is_html must be true */
	body: string;
	/** Email subject line */
	subject?: string | null;
	/** Carbon Copy (CC) recipients' email addresses */
	cc?: string[];
	/** Blind Carbon Copy (BCC) recipients' email addresses */
	bcc?: string[];
	/** Additional 'To' recipients' email addresses (not Cc or Bcc) */
	extra_recipients?: string[];
	/** Set to true if the email body contains HTML tags */
	is_html?: boolean;
	/** File to attach; ensure s3key, mimetype, and name are set if provided */
	attachment?: string;
	/** User's email address; the literal 'me' refers to the authenticated user */
	user_id?: string;
}

/**
 * Output data structure from Gmail send email operation
 */
export interface GmailSendEmailOutput {
	data: {
		/** Gmail API response, typically including the sent message ID and threadId */
		response_data: Record<string, unknown>;
	};
	/** Error message if any occurred during execution */
	error?: string | null;
	/** Whether the action execution was successful */
	successful: boolean;
}

/**
 * React hook for sending emails via Gmail using MCP integration
 *
 * Uses TanStack Query mutation for write operations with automatic
 * error handling and query cache invalidation on success.
 *
 * @returns Mutation object with mutate/mutateAsync functions and status
 */
export function useGmailSendEmail() {
	const { callTool } = useMCPClient();
	const queryClient = useQueryClient();

	return useMutation({
		mutationFn: async (params: GmailSendEmailInput) => {
			if (!params) {
				throw new Error(
					"Parameters are required for Gmail send email operation",
				);
			}

			if (!params.recipient_email || !params.body) {
				throw new Error("recipient_email and body are required fields");
			}

			// CRITICAL: Use MCPToolResponse and parse JSON response
			const mcpResponse = await callTool<MCPToolResponse, GmailSendEmailInput>(
				SERVER_URL,
				MCP_ID,
				TOOL_NAME,
				params,
			);

			if (!mcpResponse.content?.[0]?.text) {
				throw new Error("Invalid MCP response format: missing content[0].text");
			}

			try {
				const toolData: GmailSendEmailOutput = JSON.parse(
					mcpResponse.content[0].text,
				);

				if (!toolData.successful) {
					throw new Error(
						toolData.error || "Gmail send email operation failed",
					);
				}

				return toolData;
			} catch (parseError) {
				if (
					parseError instanceof Error &&
					parseError.message.includes("Gmail send email operation failed")
				) {
					throw parseError;
				}
				throw new Error(
					`Failed to parse MCP response JSON: ${parseError instanceof Error ? parseError.message : "Unknown error"}`,
				);
			}
		},
		onSuccess: () => {
			// Invalidate related Gmail queries to refresh data
			queryClient.invalidateQueries({ queryKey: ["gmail-emails"] });
			queryClient.invalidateQueries({ queryKey: ["gmail-threads"] });
		},
		retry: 2,
		retryDelay: (attemptIndex) => Math.min(1000 * 2 ** attemptIndex, 30000),
	});
}
