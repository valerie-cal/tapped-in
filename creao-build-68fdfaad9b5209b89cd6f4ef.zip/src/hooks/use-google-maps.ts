import { mapsjavascripapi } from "@/components/api/schemas/mapsjavascripapi/mapsjavascripapi";
import { getAuthToken } from "@/lib/auth-integration";
import { useMutation, useQuery } from "@tanstack/react-query";
import { useEffect, useState } from "react";

// Extend Window interface to include google property
declare global {
	interface Window {
		// biome-ignore lint/suspicious/noExplicitAny: Google Maps API is dynamically loaded
		google?: any;
	}
}

/**
 * Coordinates for a location
 */
export interface LatLng {
	lat: number;
	lng: number;
}

/**
 * Geocoding input - convert address to coordinates
 */
export interface GeocodeInput {
	address: string;
}

/**
 * Geocoding response
 */
export interface GeocodeResponse {
	location: LatLng;
	formattedAddress: string;
	placeId?: string;
}

/**
 * Custom marker configuration
 */
export interface MarkerConfig {
	position: LatLng;
	title?: string;
	icon?: string;
	label?: string;
	draggable?: boolean;
	onClick?: () => void;
}

/**
 * Map configuration
 */
export interface MapConfig {
	center: LatLng;
	zoom?: number;
	mapTypeId?: string;
	markers?: MarkerConfig[];
}

/**
 * Google Maps initialization options
 */
export interface GoogleMapsOptions {
	/**
	 * Google Maps API key
	 */
	apiKey: string;
	/**
	 * Additional libraries to load (e.g., 'places', 'geometry', 'drawing')
	 */
	libraries?: string[];
	/**
	 * Whether to automatically load the Maps API
	 */
	autoLoad?: boolean;
}

// Global flag to track if Maps API is loaded
let mapsApiLoaded = false;
let mapsApiLoadingPromise: Promise<void> | null = null;

/**
 * Load the Google Maps JavaScript API
 */
async function loadGoogleMapsApi(
	apiKey: string,
	libraries?: string[],
): Promise<void> {
	// If already loaded, return immediately
	if (mapsApiLoaded && window.google?.maps) {
		console.log("[GoogleMaps] Already loaded, skipping");
		return;
	}

	// If currently loading, wait for that to complete
	if (mapsApiLoadingPromise) {
		console.log("[GoogleMaps] Already loading, waiting...");
		return mapsApiLoadingPromise;
	}

	// Start loading
	mapsApiLoadingPromise = new Promise((resolve, reject) => {
		console.log("[GoogleMaps] Starting to load Google Maps API");

		// Create a unique callback name
		const callbackName = `initGoogleMaps_${Date.now()}`;
		console.log("[GoogleMaps] Callback name:", callbackName);

		// Set up the callback
		// biome-ignore lint/suspicious/noExplicitAny: Dynamic callback for Google Maps API
		(window as any)[callbackName] = () => {
			console.log("[GoogleMaps] Callback executed - Maps API ready!");
			mapsApiLoaded = true;
			mapsApiLoadingPromise = null;
			// biome-ignore lint/suspicious/noExplicitAny: Dynamic callback for Google Maps API
			delete (window as any)[callbackName];
			resolve();
		};

		// Add a timeout to detect if the callback is never called
		const timeout = setTimeout(() => {
			console.error("[GoogleMaps] Timeout waiting for Maps API to load");
			mapsApiLoadingPromise = null;
			// biome-ignore lint/suspicious/noExplicitAny: Dynamic callback for Google Maps API
			delete (window as any)[callbackName];
			reject(new Error("Timeout waiting for Google Maps API to load"));
		}, 15000); // 15 second timeout

		// Try to load via the API client first
		try {
			console.log("[GoogleMaps] Initializing API client...");
			const apiClient = new mapsjavascripapi({
				TOKEN: getAuthToken() || "",
			});

			console.log("[GoogleMaps] Calling loadMapsJavaScriptApi...");
			apiClient.default
				.loadMapsJavaScriptApi(
					apiKey,
					"mapsjavascripapi",
					"/maps/api/js",
					"68fd91184ee1dc116d72651f",
					callbackName,
					libraries?.join(","),
				)
				.then((scriptContent) => {
					console.log(
						"[GoogleMaps] Script content received, length:",
						scriptContent?.length,
					);
					clearTimeout(timeout);

					// Create and append script tag
					const script = document.createElement("script");
					script.text = scriptContent;
					script.async = true;
					script.defer = true;
					script.onerror = (e) => {
						console.error("[GoogleMaps] Script execution error:", e);
					};
					document.head.appendChild(script);
					console.log("[GoogleMaps] Script tag appended to document");
				})
				.catch((error) => {
					console.error(
						"[GoogleMaps] API client failed, falling back to direct load:",
						error,
					);
					clearTimeout(timeout);

					// Fallback: Load directly from Google
					const libraryParam = libraries?.length
						? `&libraries=${libraries.join(",")}`
						: "";
					const scriptUrl = `https://maps.googleapis.com/maps/api/js?key=${apiKey}${libraryParam}&callback=${callbackName}`;

					const script = document.createElement("script");
					script.src = scriptUrl;
					script.async = true;
					script.defer = true;
					script.onerror = (e) => {
						console.error("[GoogleMaps] Direct script load error:", e);
						mapsApiLoadingPromise = null;
						// biome-ignore lint/suspicious/noExplicitAny: Dynamic callback for Google Maps API
						delete (window as any)[callbackName];
						reject(new Error("Failed to load Google Maps API directly"));
					};
					document.head.appendChild(script);
					console.log("[GoogleMaps] Fallback: Direct script tag appended");
				});
		} catch (error) {
			console.error("[GoogleMaps] Error in API client initialization:", error);
			clearTimeout(timeout);

			// Direct fallback
			const libraryParam = libraries?.length
				? `&libraries=${libraries.join(",")}`
				: "";
			const scriptUrl = `https://maps.googleapis.com/maps/api/js?key=${apiKey}${libraryParam}&callback=${callbackName}`;

			const script = document.createElement("script");
			script.src = scriptUrl;
			script.async = true;
			script.defer = true;
			script.onerror = (e) => {
				console.error("[GoogleMaps] Direct script load error:", e);
				mapsApiLoadingPromise = null;
				// biome-ignore lint/suspicious/noExplicitAny: Dynamic callback for Google Maps API
				delete (window as any)[callbackName];
				reject(new Error("Failed to load Google Maps API"));
			};
			document.head.appendChild(script);
			console.log(
				"[GoogleMaps] Emergency fallback: Direct script tag appended",
			);
		}
	});

	return mapsApiLoadingPromise;
}

/**
 * React hook for Google Maps integration
 *
 * Provides comprehensive Google Maps functionality including:
 * - Loading the Maps JavaScript API
 * - Geocoding (address to coordinates)
 * - Reverse geocoding (coordinates to address)
 * - Getting user's current location
 * - Creating and managing maps with custom markers
 *
 * @example
 * ```tsx
 * const { isLoaded, geocode, getCurrentLocation, createMap } = useGoogleMaps({
 *   apiKey: 'your-api-key',
 *   libraries: ['places'],
 * });
 *
 * const handleGeocode = async () => {
 *   const result = await geocode.mutateAsync({ address: '1600 Amphitheatre Parkway' });
 *   console.log('Coordinates:', result.location);
 * };
 *
 * const handleGetLocation = async () => {
 *   const position = await getCurrentLocation();
 *   console.log('Current location:', position);
 * };
 *
 * useEffect(() => {
 *   if (isLoaded && mapContainerRef.current) {
 *     const map = createMap(mapContainerRef.current, {
 *       center: { lat: 37.7749, lng: -122.4194 },
 *       zoom: 12,
 *       markers: [
 *         { position: { lat: 37.7749, lng: -122.4194 }, title: 'San Francisco' }
 *       ]
 *     });
 *   }
 * }, [isLoaded]);
 * ```
 */
export function useGoogleMaps(options: GoogleMapsOptions) {
	const [isLoaded, setIsLoaded] = useState(mapsApiLoaded);
	const [loadError, setLoadError] = useState<Error | null>(null);

	// Load the Google Maps API on mount
	useEffect(() => {
		if (options.autoLoad !== false && !isLoaded && !loadError) {
			console.log("[GoogleMaps] Starting to load Maps API...");
			loadGoogleMapsApi(options.apiKey, options.libraries)
				.then(() => {
					console.log("[GoogleMaps] Maps API loaded successfully");
					setIsLoaded(true);
				})
				.catch((error) => {
					console.error("[GoogleMaps] Failed to load Google Maps API:", error);
					setLoadError(error);
				});
		}
	}, [
		options.apiKey,
		options.libraries,
		options.autoLoad,
		isLoaded,
		loadError,
	]);

	/**
	 * Geocode an address to coordinates
	 */
	const geocode = useMutation<GeocodeResponse, Error, GeocodeInput>({
		mutationFn: async (params: GeocodeInput): Promise<GeocodeResponse> => {
			if (!isLoaded || !window.google?.maps) {
				throw new Error("Google Maps API is not loaded");
			}

			if (!params.address || params.address.trim().length === 0) {
				throw new Error("Address is required");
			}

			const googleMaps = window.google.maps;
			const geocoder = new googleMaps.Geocoder();

			return new Promise((resolve, reject) => {
				geocoder.geocode(
					{ address: params.address },
					// biome-ignore lint/suspicious/noExplicitAny: Google Maps API callback types
					(results: any, status: any) => {
						if (status === "OK" && results && results[0]) {
							const location = results[0].geometry.location;
							resolve({
								location: {
									lat: location.lat(),
									lng: location.lng(),
								},
								formattedAddress: results[0].formatted_address,
								placeId: results[0].place_id,
							});
						} else {
							reject(new Error(`Geocoding failed: ${status}`));
						}
					},
				);
			});
		},
	});

	/**
	 * Reverse geocode coordinates to address
	 */
	const reverseGeocode = useMutation<GeocodeResponse, Error, LatLng>({
		mutationFn: async (params: LatLng): Promise<GeocodeResponse> => {
			if (!isLoaded || !window.google?.maps) {
				throw new Error("Google Maps API is not loaded");
			}

			if (typeof params.lat !== "number" || typeof params.lng !== "number") {
				throw new Error("Valid latitude and longitude are required");
			}

			const googleMaps = window.google.maps;
			const geocoder = new googleMaps.Geocoder();

			return new Promise((resolve, reject) => {
				geocoder.geocode(
					{ location: { lat: params.lat, lng: params.lng } },
					// biome-ignore lint/suspicious/noExplicitAny: Google Maps API callback types
					(results: any, status: any) => {
						if (status === "OK" && results && results[0]) {
							const location = results[0].geometry.location;
							resolve({
								location: {
									lat: location.lat(),
									lng: location.lng(),
								},
								formattedAddress: results[0].formatted_address,
								placeId: results[0].place_id,
							});
						} else {
							reject(new Error(`Reverse geocoding failed: ${status}`));
						}
					},
				);
			});
		},
	});

	/**
	 * Get user's current location using browser geolocation
	 */
	const getCurrentLocation = (): Promise<LatLng> => {
		return new Promise((resolve, reject) => {
			if (!navigator.geolocation) {
				reject(new Error("Geolocation is not supported by your browser"));
				return;
			}

			navigator.geolocation.getCurrentPosition(
				(position) => {
					resolve({
						lat: position.coords.latitude,
						lng: position.coords.longitude,
					});
				},
				(error) => {
					reject(new Error(`Geolocation error: ${error.message}`));
				},
				{
					enableHighAccuracy: true,
					timeout: 10000,
					maximumAge: 0,
				},
			);
		});
	};

	/**
	 * Create a map instance with custom configuration
	 */
	// biome-ignore lint/suspicious/noExplicitAny: Google Maps API returns untyped map instance
	const createMap = (container: HTMLElement, config: MapConfig): any => {
		if (!isLoaded || !window.google?.maps) {
			console.error("Google Maps API is not loaded");
			return null;
		}

		if (!container) {
			console.error("Container element is required");
			return null;
		}

		const googleMaps = window.google.maps;

		// Create the map
		const map = new googleMaps.Map(container, {
			center: config.center,
			zoom: config.zoom || 12,
			mapTypeId: config.mapTypeId || "roadmap",
		});

		// Add markers if provided
		if (config.markers && config.markers.length > 0) {
			// biome-ignore lint/complexity/noForEach: Simple iteration for marker creation
			config.markers.forEach((markerConfig) => {
				const marker = new googleMaps.Marker({
					position: markerConfig.position,
					map: map,
					title: markerConfig.title,
					icon: markerConfig.icon,
					label: markerConfig.label,
					draggable: markerConfig.draggable,
				});

				// Add click listener if provided
				if (markerConfig.onClick) {
					marker.addListener("click", markerConfig.onClick);
				}
			});
		}

		return map;
	};

	/**
	 * Create a custom marker
	 */
	// biome-ignore lint/suspicious/noExplicitAny: Google Maps API uses untyped map and marker instances
	const createMarker = (map: any, config: MarkerConfig): any => {
		if (!isLoaded || !window.google?.maps) {
			console.error("Google Maps API is not loaded");
			return null;
		}

		const googleMaps = window.google.maps;

		const marker = new googleMaps.Marker({
			position: config.position,
			map: map,
			title: config.title,
			icon: config.icon,
			label: config.label,
			draggable: config.draggable,
		});

		// Add click listener if provided
		if (config.onClick) {
			marker.addListener("click", config.onClick);
		}

		return marker;
	};

	return {
		// Loading state
		isLoaded,
		isLoading: !isLoaded && !loadError,
		loadError,

		// Geocoding
		geocode,
		reverseGeocode,

		// Location
		getCurrentLocation,

		// Map creation
		createMap,
		createMarker,

		// Direct access to Google Maps API
		google: isLoaded ? window.google : undefined,
	};
}
