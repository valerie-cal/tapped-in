import { CreaoFileUpload } from "@/components/api/schemas/CreaoFileUpload/CreaoFileUpload";
import { getAuthToken } from "@/lib/auth-integration";
import { useMutation } from "@tanstack/react-query";

/**
 * Input parameters for file upload
 */
export interface CreaoFileUploadInput {
	/**
	 * The file to upload
	 */
	file: File;
}

/**
 * Response from file upload
 */
export interface CreaoFileUploadResponse {
	/**
	 * Whether the upload was successful
	 */
	success: boolean;
	/**
	 * The permanent URL where the uploaded file can be accessed
	 */
	fileUrl: string;
	/**
	 * The S3 key (path) of the uploaded file
	 */
	fileKey: string;
	/**
	 * File metadata
	 */
	metadata: {
		fileName: string;
		contentType: string;
		fileSize: number;
	};
}

/**
 * React hook for secure file upload to S3 via presigned URLs
 *
 * This hook handles the complete upload flow:
 * 1. Requests a presigned URL from the backend
 * 2. Uploads the file directly to S3 using the presigned URL
 * 3. Returns the permanent URL where the file can be accessed
 *
 * @example
 * ```tsx
 * const uploadMutation = useCreaoFileUpload();
 *
 * const handleFileSelect = async (event: React.ChangeEvent<HTMLInputElement>) => {
 *   const file = event.target.files?.[0];
 *   if (!file) return;
 *
 *   try {
 *     const result = await uploadMutation.mutateAsync({ file });
 *     console.log('File uploaded to:', result.fileUrl);
 *   } catch (error) {
 *     console.error('Upload failed:', error);
 *   }
 * };
 *
 * return (
 *   <div>
 *     <input type="file" onChange={handleFileSelect} />
 *     {uploadMutation.isPending && <p>Uploading...</p>}
 *     {uploadMutation.isError && <p>Upload failed</p>}
 *   </div>
 * );
 * ```
 */
export function useCreaoFileUpload() {
	return useMutation<CreaoFileUploadResponse, Error, CreaoFileUploadInput>({
		mutationFn: async (
			params: CreaoFileUploadInput,
		): Promise<CreaoFileUploadResponse> => {
			// Validate file object
			if (!params.file || !(params.file instanceof File)) {
				throw new Error("Valid file object is required");
			}

			// Validate file size (max 100MB)
			const MAX_FILE_SIZE = 100 * 1024 * 1024; // 100MB
			if (params.file.size > MAX_FILE_SIZE) {
				throw new Error(
					`File size exceeds maximum allowed size of ${MAX_FILE_SIZE / (1024 * 1024)}MB`,
				);
			}

			// Validate file type for images
			const allowedTypes = [
				"image/jpeg",
				"image/jpg",
				"image/png",
				"image/gif",
				"image/webp",
				"image/svg+xml",
			];
			if (!allowedTypes.includes(params.file.type)) {
				throw new Error(
					`File type ${params.file.type} is not allowed. Allowed types: ${allowedTypes.join(", ")}`,
				);
			}

			// Initialize API client with authentication
			const apiClient = new CreaoFileUpload({
				TOKEN: getAuthToken() || "",
			});

			// Step 1: Get presigned URL from backend
			const presignedResponse =
				await apiClient.default.postMainOfficialApiPresignS3Upload({
					fileName: params.file.name,
					contentType: params.file.type,
				});

			// Validate presigned response
			if (
				!presignedResponse.success ||
				!presignedResponse.presignedUrl ||
				!presignedResponse.realFileUrl
			) {
				throw new Error("Failed to generate presigned URL for upload");
			}

			// Step 2: Upload file to S3 using presigned URL
			try {
				const uploadResponse = await fetch(presignedResponse.presignedUrl, {
					method: "PUT",
					body: params.file,
					headers: {
						"Content-Type": params.file.type,
					},
				});

				if (!uploadResponse.ok) {
					throw new Error(
						`S3 upload failed with status: ${uploadResponse.status}`,
					);
				}
			} catch (uploadError) {
				console.error("S3 upload error:", uploadError);
				throw new Error("Failed to upload file to S3. Please try again.");
			}

			// Step 3: Return success response with file URL
			return {
				success: true,
				fileUrl: presignedResponse.realFileUrl,
				fileKey: presignedResponse.fileKey || "",
				metadata: {
					fileName: params.file.name,
					contentType: params.file.type,
					fileSize: params.file.size,
				},
			};
		},
	});
}
