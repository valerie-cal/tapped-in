import { type MCPToolResponse, useMCPClient } from "@/hooks/use-mcp-client";
import { useMutation, useQueryClient } from "@tanstack/react-query";

// MCP Configuration
const MCP_ID = "6874a16d565d2b53f95cd043";
const SERVER_URL =
	"https://mcp.composio.dev/composio/server/a123b074-4724-4fa8-89c2-a7746b7f8828/mcp?user_id=68fd8ddc75e06ca1e8950833";
const TOOL_NAME = "GOOGLECALENDAR_CREATE_EVENT";

/**
 * Input parameters for creating a Google Calendar event
 */
export interface GoogleCalendarCreateEventInput {
	/** Naive date/time (YYYY-MM-DDTHH:MM:SS) with NO offsets or Z. e.g. '2025-01-16T13:00:00' */
	start_datetime: string;
	/** Target calendar: 'primary' for the user's main calendar, or the calendar's email address */
	calendar_id?: string;
	/** Summary (title) of the event */
	summary?: string | null;
	/** Description of the event. Can contain HTML. */
	description?: string | null;
	/** Geographic location of the event as free-form text */
	location?: string | null;
	/** List of attendee emails (strings) */
	attendees?: string[] | null;
	/** Number of hours (0-24). Increase by 1 here rather than passing 60 in event_duration_minutes */
	event_duration_hour?: number;
	/** Duration in minutes (0-59 ONLY). NEVER use 60+ minutes - use event_duration_hour=1 instead */
	event_duration_minutes?: number;
	/** IANA timezone name (e.g., 'America/New_York'). Required if datetime is naive */
	timezone?: string | null;
	/** Type of the event: 'birthday', 'default', 'focusTime', 'outOfOffice', 'workingLocation' */
	eventType?:
		| "birthday"
		| "default"
		| "focusTime"
		| "outOfOffice"
		| "workingLocation";
	/** Event visibility: 'default', 'public', 'private', or 'confidential' */
	visibility?: "default" | "public" | "private" | "confidential";
	/** 'opaque' (busy) or 'transparent' (available) */
	transparency?: "opaque" | "transparent";
	/** If true, a Google Meet link is created (requires paid Google Workspace account) */
	create_meeting_room?: boolean | null;
	/** If true, guests can modify the event */
	guests_can_modify?: boolean;
	/** Whether attendees other than the organizer can invite others to the event */
	guestsCanInviteOthers?: boolean | null;
	/** Whether attendees other than the organizer can see who the event's attendees are */
	guestsCanSeeOtherGuests?: boolean | null;
	/** List of RRULE, EXRULE, RDATE, EXDATE lines for recurring events */
	recurrence?: string[] | null;
	/** Whether to send updates to the attendees */
	send_updates?: boolean | null;
	/** If true, the organizer will NOT be added as an attendee */
	exclude_organizer?: boolean;
}

/**
 * Output data structure from Google Calendar create event operation
 */
export interface GoogleCalendarCreateEventOutput {
	data: {
		/** Full representation of the created event resource from Google Calendar API */
		response_data: Record<string, unknown>;
	};
	/** Error message if any occurred during execution */
	error?: string | null;
	/** Whether the action execution was successful */
	successful: boolean;
}

/**
 * React hook for creating Google Calendar events using MCP integration
 *
 * Uses TanStack Query mutation for write operations with automatic
 * error handling and query cache invalidation on success.
 *
 * @returns Mutation object with mutate/mutateAsync functions and status
 */
export function useGoogleCalendarCreateEvent() {
	const { callTool } = useMCPClient();
	const queryClient = useQueryClient();

	return useMutation({
		mutationFn: async (params: GoogleCalendarCreateEventInput) => {
			if (!params) {
				throw new Error(
					"Parameters are required for Google Calendar create event operation",
				);
			}

			if (!params.start_datetime) {
				throw new Error("start_datetime is a required field");
			}

			// CRITICAL: Use MCPToolResponse and parse JSON response
			const mcpResponse = await callTool<
				MCPToolResponse,
				GoogleCalendarCreateEventInput
			>(SERVER_URL, MCP_ID, TOOL_NAME, params);

			if (!mcpResponse.content?.[0]?.text) {
				throw new Error("Invalid MCP response format: missing content[0].text");
			}

			try {
				const toolData: GoogleCalendarCreateEventOutput = JSON.parse(
					mcpResponse.content[0].text,
				);

				if (!toolData.successful) {
					throw new Error(
						toolData.error || "Google Calendar create event operation failed",
					);
				}

				return toolData;
			} catch (parseError) {
				if (
					parseError instanceof Error &&
					parseError.message.includes(
						"Google Calendar create event operation failed",
					)
				) {
					throw parseError;
				}
				throw new Error(
					`Failed to parse MCP response JSON: ${parseError instanceof Error ? parseError.message : "Unknown error"}`,
				);
			}
		},
		onSuccess: () => {
			// Invalidate related Google Calendar queries to refresh data
			queryClient.invalidateQueries({ queryKey: ["google-calendar-events"] });
			queryClient.invalidateQueries({ queryKey: ["google-calendar-event"] });
		},
		retry: 2,
		retryDelay: (attemptIndex) => Math.min(1000 * 2 ** attemptIndex, 30000),
	});
}
