import { OpenAIGPTChat } from "@/components/api/schemas/OpenAIGPTChat/OpenAIGPTChat";
import { getAuthToken } from "@/lib/auth-integration";
import { useMutation } from "@tanstack/react-query";

/**
 * Input parameters for OpenAI event tagging
 */
export interface OpenAIEventTaggingInput {
	/**
	 * The event description to analyze for tag suggestions
	 */
	eventDescription: string;
	/**
	 * Optional model to use (defaults to gpt-4)
	 */
	model?: string;
}

/**
 * Response from OpenAI event tagging
 */
export interface OpenAIEventTaggingResponse {
	/**
	 * Array of suggested tags for the event
	 */
	tags: string[];
	/**
	 * Suggested category for the event
	 */
	category: string;
	/**
	 * Raw response from OpenAI for debugging
	 */
	rawResponse?: {
		id: string;
		model: string;
		created: number;
		usage: {
			prompt_tokens: number;
			completion_tokens: number;
			total_tokens: number;
		};
	};
}

/**
 * React hook for AI-powered event tagging using OpenAI GPT
 *
 * Analyzes event descriptions and suggests relevant tags and categories
 * to help organize and categorize events.
 *
 * @example
 * ```tsx
 * const tagEventMutation = useOpenAIEventTagging();
 *
 * const handleAnalyzeEvent = async () => {
 *   try {
 *     const result = await tagEventMutation.mutateAsync({
 *       eventDescription: "Annual tech conference featuring AI and machine learning talks"
 *     });
 *     console.log('Suggested tags:', result.tags);
 *     console.log('Category:', result.category);
 *   } catch (error) {
 *     console.error('Tagging failed:', error);
 *   }
 * };
 * ```
 */
export function useOpenAIEventTagging() {
	return useMutation<
		OpenAIEventTaggingResponse,
		Error,
		OpenAIEventTaggingInput
	>({
		mutationFn: async (
			params: OpenAIEventTaggingInput,
		): Promise<OpenAIEventTaggingResponse> => {
			// Validate input
			if (
				!params.eventDescription ||
				params.eventDescription.trim().length === 0
			) {
				throw new Error("Event description is required and cannot be empty");
			}

			// Initialize API client with authentication
			const apiClient = new OpenAIGPTChat({
				TOKEN: getAuthToken() || "",
			});

			// Create system prompt for tag and category generation
			const systemPrompt = `You are an expert event categorization assistant. Analyze the event description and provide:
1. A list of 3-7 relevant tags (keywords) that describe the event
2. A single category that best fits the event

Respond ONLY with valid JSON in this exact format:
{
  "tags": ["tag1", "tag2", "tag3"],
  "category": "category_name"
}

Categories should be general like: "Technology", "Business", "Arts & Culture", "Sports", "Education", "Health & Wellness", "Food & Drink", "Community", "Entertainment", etc.
Tags should be specific, relevant keywords from the description.`;

			// Call the OpenAI API
			const response = await apiClient.default.createChatCompletion({
				model: params.model || "gpt-4",
				messages: [
					{
						role: "system",
						content: systemPrompt,
					},
					{
						role: "user",
						content: `Event description: ${params.eventDescription}`,
					},
				],
			});

			// Extract the assistant's response
			if (!response.choices || response.choices.length === 0) {
				throw new Error("No response received from OpenAI");
			}

			const assistantMessage = response.choices[0].message.content;

			if (!assistantMessage) {
				throw new Error("Empty response content from OpenAI");
			}

			// Parse the JSON response
			let parsedResponse: { tags: string[]; category: string };
			try {
				parsedResponse = JSON.parse(assistantMessage);
			} catch (parseError) {
				console.error("Failed to parse OpenAI response:", assistantMessage);
				throw new Error("Invalid JSON response from OpenAI. Please try again.");
			}

			// Validate the response structure
			if (
				!Array.isArray(parsedResponse.tags) ||
				typeof parsedResponse.category !== "string"
			) {
				throw new Error("Invalid response format from OpenAI");
			}

			// Return formatted response
			return {
				tags: parsedResponse.tags,
				category: parsedResponse.category,
				rawResponse: {
					id: response.id,
					model: response.model,
					created: response.created,
					usage: response.usage,
				},
			};
		},
	});
}
